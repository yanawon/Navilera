# Navilos
Step by step RTOS for study embedded FW programming.

나빌로스는 임베디드 펌웨어 프로그래밍을 공부하기 위해 제작한 작고 간단한 RTOS입니다.
